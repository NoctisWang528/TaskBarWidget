#include "headsetcontrol_c.h"
#include "headsetcontrol.hpp"

#include <cstring>
#include <string>
#include <vector>

// ============================================================================
// Internal State
// ============================================================================

namespace {

// Store discovered headsets and their string names
struct HeadsetWrapper {
    headsetcontrol::Headset headset;
    std::string name_str; // Persistent storage for C string
    std::string vendor_name_str;
    std::string product_name_str;
    std::optional<EqualizerPresets> equalizer_presets_cache;
    std::string sidetone_level_name_cache;

    explicit HeadsetWrapper(headsetcontrol::Headset&& h)
        : headset(std::move(h))
        , name_str(headset.name())
        , vendor_name_str(headset.vendorName())
        , product_name_str(headset.productName())
    {
    }
};

// Cache for supported device names (lazily populated on first access)
// NOLINTBEGIN(cppcoreguidelines-avoid-non-const-global-variables)
std::vector<std::string> g_supported_device_names;
bool g_supported_devices_cached = false;
// NOLINTEND(cppcoreguidelines-avoid-non-const-global-variables)

void ensureSupportedDevicesCached()
{
    if (!g_supported_devices_cached) {
        g_supported_device_names.clear();
        for (auto name : headsetcontrol::supportedDevices()) {
            g_supported_device_names.emplace_back(name);
        }
        g_supported_devices_cached = true;
    }
}

// Convert C++ error to C error code
hsc_result_t toErrorCode(const headsetcontrol::DeviceError& error)
{
    switch (error.code) {
    case headsetcontrol::DeviceError::Code::Success:
        return HSC_RESULT_OK;
    case headsetcontrol::DeviceError::Code::Timeout:
        return HSC_RESULT_TIMEOUT;
    case headsetcontrol::DeviceError::Code::DeviceOffline:
        return HSC_RESULT_DEVICE_OFFLINE;
    case headsetcontrol::DeviceError::Code::NotSupported:
        return HSC_RESULT_NOT_SUPPORTED;
    case headsetcontrol::DeviceError::Code::InvalidParameter:
        return HSC_RESULT_INVALID_PARAM;
    case headsetcontrol::DeviceError::Code::HIDError:
        return HSC_RESULT_HID_ERROR;
    default:
        return HSC_RESULT_ERROR;
    }
}

// Version string storage (lazily initialized)
// NOLINTNEXTLINE(cppcoreguidelines-avoid-non-const-global-variables)
std::string g_version_str;

const EqualizerPresets* getCachedEqualizerPresets(HeadsetWrapper& wrapper)
{
    if (!wrapper.equalizer_presets_cache.has_value()) {
        wrapper.equalizer_presets_cache = wrapper.headset.getEqualizerPresets();
    }

    if (!wrapper.equalizer_presets_cache.has_value()) {
        return nullptr;
    }

    return &(*wrapper.equalizer_presets_cache);
}

void copySidetoneStatus(const headsetcontrol::SidetoneResult& source,
    hsc_sidetone_status_t& destination, std::string& level_name_cache)
{
    destination.current_level = source.current_level;
    destination.min_level     = source.min_level;
    destination.max_level     = source.max_level;
    destination.device_level  = source.device_level;
    destination.device_min    = source.device_min;
    destination.device_max    = source.device_max;
    level_name_cache          = source.level_name.value_or("");
    destination.level_name    = level_name_cache.empty() ? nullptr : level_name_cache.c_str();
}

} // namespace

// ============================================================================
// Discovery Functions
// ============================================================================

extern "C" {

int hsc_discover(hsc_headset_t** headsets)
{
    if (!headsets) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto discovered = headsetcontrol::discover();

    if (discovered.empty()) {
        *headsets = nullptr;
        return 0;
    }

    // Allocate array of handles
    *headsets = static_cast<hsc_headset_t*>(
        malloc(discovered.size() * sizeof(hsc_headset_t)));

    if (!*headsets) {
        return HSC_RESULT_ERROR;
    }

    // Create wrappers for each headset
    // NOLINTBEGIN(cppcoreguidelines-owning-memory)
    // Raw new/delete required: C API where caller manages lifetime via hsc_free_headsets()
    for (size_t i = 0; i < discovered.size(); i++) {
        (*headsets)[i] = new HeadsetWrapper(std::move(discovered[i]));
    }
    // NOLINTEND(cppcoreguidelines-owning-memory)

    return static_cast<int>(discovered.size());
}

void hsc_free_headsets(hsc_headset_t* headsets, int count)
{
    if (!headsets) {
        return;
    }

    // NOLINTBEGIN(cppcoreguidelines-owning-memory)
    // Raw delete required: C API paired with hsc_discover() allocation
    for (int i = 0; i < count; i++) {
        delete static_cast<HeadsetWrapper*>(headsets[i]);
    }

    // NOLINTNEXTLINE(bugprone-multi-level-implicit-pointer-conversion)
    free(headsets);
    // NOLINTEND(cppcoreguidelines-owning-memory)
}

const char* hsc_version(void)
{
    if (g_version_str.empty()) {
        g_version_str = std::string(headsetcontrol::version());
    }
    return g_version_str.c_str();
}

int hsc_supported_device_count(void)
{
    ensureSupportedDevicesCached();
    return static_cast<int>(g_supported_device_names.size());
}

const char* hsc_supported_device_name(int index)
{
    ensureSupportedDevicesCached();
    if (index < 0 || index >= static_cast<int>(g_supported_device_names.size())) {
        return nullptr;
    }
    return g_supported_device_names[index].c_str();
}

// ============================================================================
// Headset Information
// ============================================================================

const char* hsc_get_name(hsc_headset_t headset)
{
    if (!headset) {
        return nullptr;
    }
    return static_cast<HeadsetWrapper*>(headset)->name_str.c_str();
}

uint16_t hsc_get_vendor_id(hsc_headset_t headset)
{
    if (!headset) {
        return 0;
    }
    return static_cast<HeadsetWrapper*>(headset)->headset.vendorId();
}

const char* hsc_get_vendor_name(hsc_headset_t headset)
{
    if (!headset) {
        return nullptr;
    }

    const auto& vendor_name = static_cast<HeadsetWrapper*>(headset)->vendor_name_str;
    return vendor_name.empty() ? nullptr : vendor_name.c_str();
}

uint16_t hsc_get_product_id(hsc_headset_t headset)
{
    if (!headset) {
        return 0;
    }
    return static_cast<HeadsetWrapper*>(headset)->headset.productId();
}

const char* hsc_get_product_name(hsc_headset_t headset)
{
    if (!headset) {
        return nullptr;
    }

    const auto& product_name = static_cast<HeadsetWrapper*>(headset)->product_name_str;
    return product_name.empty() ? nullptr : product_name.c_str();
}

bool hsc_supports(hsc_headset_t headset, hsc_capability_t cap)
{
    if (!headset) {
        return false;
    }
    return static_cast<HeadsetWrapper*>(headset)->headset.supports(
        static_cast<capabilities>(cap));
}

int hsc_get_capabilities(hsc_headset_t headset)
{
    if (!headset) {
        return 0;
    }
    return static_cast<HeadsetWrapper*>(headset)->headset.capabilitiesMask();
}

// ============================================================================
// Battery & Status
// ============================================================================

hsc_result_t hsc_get_battery(hsc_headset_t headset, hsc_battery_t* battery)
{
    if (!headset || !battery) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.getBattery();

    if (!result) {
        return toErrorCode(result.error());
    }

    battery->level_percent     = result->level_percent;
    battery->status            = static_cast<hsc_battery_status_t>(result->status);
    battery->voltage_mv        = result->voltage_mv.value_or(-1);
    battery->time_to_full_min  = result->time_to_full_min.value_or(-1);
    battery->time_to_empty_min = result->time_to_empty_min.value_or(-1);

    return HSC_RESULT_OK;
}

hsc_result_t hsc_get_chatmix(hsc_headset_t headset, hsc_chatmix_t* chatmix)
{
    if (!headset || !chatmix) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.getChatmix();

    if (!result) {
        return toErrorCode(result.error());
    }

    chatmix->level               = result->level;
    chatmix->game_volume_percent = result->game_volume_percent;
    chatmix->chat_volume_percent = result->chat_volume_percent;

    return HSC_RESULT_OK;
}

hsc_result_t hsc_get_sidetone(hsc_headset_t headset, hsc_sidetone_status_t* sidetone)
{
    if (!headset || !sidetone) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto& wrapper = *static_cast<HeadsetWrapper*>(headset);
    auto result   = wrapper.headset.getSidetone();
    if (!result) {
        return toErrorCode(result.error());
    }

    copySidetoneStatus(*result, *sidetone, wrapper.sidetone_level_name_cache);
    return HSC_RESULT_OK;
}

// ============================================================================
// Audio Controls
// ============================================================================

hsc_result_t hsc_set_sidetone(hsc_headset_t headset, uint8_t level, hsc_sidetone_t* result_out)
{
    if (!headset) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.setSidetone(level);

    if (!result) {
        return toErrorCode(result.error());
    }

    if (result_out) {
        result_out->current_level = result->current_level;
        result_out->min_level     = result->min_level;
        result_out->max_level     = result->max_level;
    }

    return HSC_RESULT_OK;
}

hsc_result_t hsc_set_volume_limiter(hsc_headset_t headset, bool enabled)
{
    if (!headset) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.setVolumeLimiter(enabled);
    return result ? HSC_RESULT_OK : toErrorCode(result.error());
}

// ============================================================================
// Equalizer
// ============================================================================

hsc_result_t hsc_set_equalizer_preset(hsc_headset_t headset, uint8_t preset)
{
    if (!headset) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.setEqualizerPreset(preset);
    return result ? HSC_RESULT_OK : toErrorCode(result.error());
}

hsc_result_t hsc_set_equalizer(hsc_headset_t headset, const float* bands, int num_bands)
{
    if (!headset || !bands || num_bands <= 0) {
        return HSC_RESULT_INVALID_PARAM;
    }

    EqualizerSettings settings({ bands, bands + num_bands });
    auto result = static_cast<HeadsetWrapper*>(headset)->headset.setEqualizer(settings);
    return result ? HSC_RESULT_OK : toErrorCode(result.error());
}

int hsc_get_equalizer_presets_count(hsc_headset_t headset)
{
    if (!headset) {
        return 0;
    }
    return static_cast<HeadsetWrapper*>(headset)->headset.getEqualizerPresetsCount();
}

const char* hsc_get_equalizer_preset_name(hsc_headset_t headset, int preset)
{
    if (!headset || preset < 0) {
        return nullptr;
    }

    auto& wrapper       = *static_cast<HeadsetWrapper*>(headset);
    const auto* presets = getCachedEqualizerPresets(wrapper);
    if (!presets || preset >= static_cast<int>(presets->presets.size())) {
        return nullptr;
    }

    return presets->presets[static_cast<size_t>(preset)].name.c_str();
}

int hsc_get_equalizer_preset_band_count(hsc_headset_t headset, int preset)
{
    if (!headset || preset < 0) {
        return 0;
    }

    auto& wrapper       = *static_cast<HeadsetWrapper*>(headset);
    const auto* presets = getCachedEqualizerPresets(wrapper);
    if (!presets || preset >= static_cast<int>(presets->presets.size())) {
        return 0;
    }

    return static_cast<int>(presets->presets[static_cast<size_t>(preset)].values.size());
}

hsc_result_t hsc_get_equalizer_preset_bands(
    hsc_headset_t headset,
    int preset,
    float* bands,
    int num_bands)
{
    if (!headset || !bands || preset < 0 || num_bands <= 0) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto& wrapper       = *static_cast<HeadsetWrapper*>(headset);
    const auto* presets = getCachedEqualizerPresets(wrapper);
    if (!presets) {
        return HSC_RESULT_NOT_SUPPORTED;
    }

    if (preset >= static_cast<int>(presets->presets.size())) {
        return HSC_RESULT_INVALID_PARAM;
    }

    const auto& values = presets->presets[static_cast<size_t>(preset)].values;
    if (num_bands < static_cast<int>(values.size())) {
        return HSC_RESULT_INVALID_PARAM;
    }

    std::memcpy(bands, values.data(), values.size() * sizeof(float));
    return HSC_RESULT_OK;
}

// ============================================================================
// Microphone
// ============================================================================

hsc_result_t hsc_set_mic_volume(hsc_headset_t headset, uint8_t volume)
{
    if (!headset) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.setMicVolume(volume);
    return result ? HSC_RESULT_OK : toErrorCode(result.error());
}

hsc_result_t hsc_set_mic_mute_led_brightness(hsc_headset_t headset, uint8_t brightness)
{
    if (!headset) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.setMicMuteLedBrightness(brightness);
    return result ? HSC_RESULT_OK : toErrorCode(result.error());
}

hsc_result_t hsc_set_rotate_to_mute(hsc_headset_t headset, bool enabled)
{
    if (!headset) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.setRotateToMute(enabled);
    return result ? HSC_RESULT_OK : toErrorCode(result.error());
}

// ============================================================================
// Lights & Audio Cues
// ============================================================================

hsc_result_t hsc_set_lights(hsc_headset_t headset, bool enabled)
{
    if (!headset) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.setLights(enabled);
    return result ? HSC_RESULT_OK : toErrorCode(result.error());
}

hsc_result_t hsc_set_voice_prompts(hsc_headset_t headset, bool enabled)
{
    if (!headset) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.setVoicePrompts(enabled);
    return result ? HSC_RESULT_OK : toErrorCode(result.error());
}

hsc_result_t hsc_play_notification_sound(hsc_headset_t headset, uint8_t sound_id)
{
    if (!headset) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.playNotificationSound(sound_id);
    return result ? HSC_RESULT_OK : toErrorCode(result.error());
}

// ============================================================================
// Power & Bluetooth
// ============================================================================

hsc_result_t hsc_set_inactive_time(hsc_headset_t headset, uint8_t minutes, hsc_inactive_time_t* result_out)
{
    if (!headset) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.setInactiveTime(minutes);

    if (!result) {
        return toErrorCode(result.error());
    }

    if (result_out) {
        result_out->minutes     = result->minutes;
        result_out->min_minutes = result->min_minutes;
        result_out->max_minutes = result->max_minutes;
    }

    return HSC_RESULT_OK;
}

hsc_result_t hsc_set_bluetooth_when_powered_on(hsc_headset_t headset, bool enabled)
{
    if (!headset) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.setBluetoothWhenPoweredOn(enabled);
    return result ? HSC_RESULT_OK : toErrorCode(result.error());
}

hsc_result_t hsc_set_bluetooth_call_volume(hsc_headset_t headset, uint8_t volume)
{
    if (!headset) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.setBluetoothCallVolume(volume);
    return result ? HSC_RESULT_OK : toErrorCode(result.error());
}

// ============================================================================
// Test Device Mode
// ============================================================================

void hsc_enable_test_device(bool enabled)
{
    headsetcontrol::enableTestDevice(enabled);
}

bool hsc_is_test_device_enabled(void)
{
    return headsetcontrol::isTestDeviceEnabled();
}

// ============================================================================
// Configuration
// ============================================================================

void hsc_set_device_timeout(int timeout_ms)
{
    headsetcontrol::setDeviceTimeout(timeout_ms);
}

int hsc_get_device_timeout(void)
{
    return headsetcontrol::getDeviceTimeout();
}

void hsc_set_test_profile(int profile)
{
    headsetcontrol::setTestProfile(profile);
}

int hsc_get_test_profile(void)
{
    return headsetcontrol::getTestProfile();
}

} // extern "C"
